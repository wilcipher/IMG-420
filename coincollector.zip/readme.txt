Wil Johnson
IMG 420
Assignment 1

Controls:
Arrow Keys and W D for movement
Space for Jump 

Collect Coins!

Win by collecting them all! 

Lose by falling off the platforms

Asset Credits: 
I created the Player Character 
The rest of the assets are by Brackeys on itch.io 